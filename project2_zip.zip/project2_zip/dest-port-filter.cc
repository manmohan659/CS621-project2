#include "dest-port-filter.h"
namespace ns3
{
NS_OBJECT_ENSURE_REGISTERED(DestPortFilter);
}
